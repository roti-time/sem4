#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <string.h>

#define PORT 3001

int main()
{
    int clientSocket;
    struct sockaddr_in serverAddress;
    char buffer[1024];

    // Create client socket
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1)
    {
        printf("Failed to create client socket.\n");
        return 1;
    }

    // Prepare server address
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(PORT);
    serverAddress.sin_addr.s_addr = INADDR_ANY;

    // Connect to the server
    if (connect(clientSocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) == -1)
    {
        printf("Failed to connect to the server.\n");
        return 1;
    }

    printf("\n\nWhat type of user are you?\n\n");

    memset(buffer, 0, sizeof(buffer));
    fgets(buffer, sizeof(buffer), stdin);
    int choice;
    if (strcmp(buffer, "student"))
        choice=1;
    else if(strcmp(buffer, "teacher"))
        choice=2;

    // Send user type to the server
    write(clientSocket, buffer, sizeof(buffer));

    if (choice==1)
    {
        // Get student roll number
        printf("\n\nEnter your roll number: ");
        memset(buffer, 0, sizeof(buffer));
        fgets(buffer, sizeof(buffer), stdin);

        // Send roll number to the server
        write(clientSocket, buffer, sizeof(buffer));

        // Receive and display student information from the server
        memset(buffer, 0, sizeof(buffer));
        read(clientSocket, buffer, sizeof(buffer));
        printf("%s",buffer);
    }
    else if (choice==2)
    {
        // Get teacher name
        printf("\n\nEnter your name: ");
        memset(buffer, 0, sizeof(buffer));
        fgets(buffer, sizeof(buffer), stdin);

        // Send teacher name to the server
        write(clientSocket, buffer, sizeof(buffer));

        // Receive and display teacher options from the server
        memset(buffer, 0, sizeof(buffer));
        read(clientSocket, buffer, sizeof(buffer));
        printf("%s",buffer);
    }
    else
    {
        // Invalid user type
        printf("\n\nInvalid user type. Please try again.\n\n");
    }

    // Close client socket
    close(clientSocket);

    return 0;
}