#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <string.h>

void handle_client(int clientSocket)
{
    char buffer[1024];
    int choice;
    int BUFFER_SIZE = 1024;
    memset(buffer, 0, sizeof(buffer));
    read(clientSocket, buffer, sizeof(buffer));

        printf("%s",buffer);

    if (strcmp(buffer, "student"))
        choice=1;
    else if(strcmp(buffer, "teacher"))
        choice=2;
    if(choice==1)
    {
        // Handle student functionality
        // Receive roll number from the client
        memset(buffer, 0, sizeof(buffer));
        read(clientSocket, buffer, sizeof(buffer));

        FILE *studentFile = fopen("student.txt", "r");
        if (studentFile == NULL)
        {
            // File doesn't exist, ask the student to provide information
            char response[] = "\nYour information is not available\n";
            write(clientSocket, response, sizeof(response));

        }
        else
        {
            // File exists, search for the student information based on roll number
            char rollNumber[BUFFER_SIZE];
            memset(rollNumber, 0, sizeof(rollNumber));
            strcpy(rollNumber, buffer);

            char studentInfo[BUFFER_SIZE];
            memset(studentInfo, 0, sizeof(studentInfo));
            int found = 0;

            while (fgets(buffer, sizeof(buffer), studentFile) != NULL)
            {
                if (strcmp(buffer, rollNumber))
                {
                    fgets(studentInfo, sizeof(studentInfo), studentFile);
                    found = 1;
                    break;
                }
            }

            fclose(studentFile);

            if (found)
            {
                // Send student information to the student
                write(clientSocket, studentInfo, sizeof(studentInfo));
            }
            else
            {
                // Student information not found
                char errorMsg[] = "Your information is not available.";
                write(clientSocket, errorMsg, sizeof(errorMsg));
            }
        }
    }
    else if (choice==2)
    {
        // Handle teacher functionality
        // Receive teacher name from the client
        memset(buffer, 0, sizeof(buffer));
        read(clientSocket, buffer, sizeof(buffer));

        FILE *teacherFile = fopen("teacher.txt", "r");
        if (teacherFile == NULL)
        {
            // File doesn't exist, ask the teacher if they want to create it
            char response[] = "Teacher database not found. Do you want to create it? (yes/no)";
            write(clientSocket, response, sizeof(response));

            // Receive teacher's response
            memset(buffer, 0, sizeof(buffer));
            read(clientSocket, buffer, sizeof(buffer));

            // Check if the teacher wants to create the database file
            if (strcmp(buffer, "yes") == 0)
            {
                // Create teacher database file
                teacherFile = fopen("teacher.txt", "w");
                if (teacherFile == NULL)
                {
                    perror("Error creating teacher file");
                    exit(EXIT_FAILURE);
                }

                // Send success message to the teacher
                char successMsg[] = "Teacher database created.";
                write(clientSocket, successMsg, sizeof(successMsg));

                fclose(teacherFile);
            }
            else
            {
                // Send refusal message to the teacher
                char refusalMsg[] = "Teacher database creation refused.";
                write(clientSocket, refusalMsg, sizeof(refusalMsg));
            }
        }
        else
        {
            // File exists, send teacher information to the teacher
            char teacherInfo[BUFFER_SIZE];
            memset(teacherInfo, 0, sizeof(teacherInfo));
            fgets(teacherInfo, sizeof(teacherInfo), teacherFile);
            fclose(teacherFile);

            // Send teacher information to the teacher
            write(clientSocket, teacherInfo, sizeof(teacherInfo));
        }
    }
    else
    {
        // Invalid user type
        char buffer1 = "Invalid user type. Please try again.";
        write(clientSocket, buffer1, sizeof(buffer1));
    }

    close(clientSocket);
}

int main()
{
    int server_socket, client_socket;
    struct sockaddr_in server_address, client_address;
    socklen_t client_address_len = sizeof(client_address);
    pid_t pid;
    // Create the server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1)
    {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    // Configure server address
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(3001);
    // Bind the socket to the specified IP and port
    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) == -1)
    {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }
    // Listen for incoming connections
    if (listen(server_socket, 2) == -1)
    {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }
    printf("Server started. Listening on port %d...\n", 3001);
    while (1)
    {
        // Accept incoming connection
        client_socket = accept(server_socket, (struct sockaddr *)&client_address, &client_address_len);
        if (client_socket == -1)
        {
            perror("Accept failed");
            continue;
        }
        // Fork a new process to handle the client
        pid = fork();
        if (pid == -1)
        {
            perror("Fork failed");
            close(client_socket);
            continue;
        }
        else if (pid == 0)
        {                         // Child process
            close(server_socket); // Close the server socket in child process
            handle_client(client_socket);
            close(client_socket);
            exit(EXIT_SUCCESS);
        }
        else
        {                         // Parent process
            close(client_socket); // Close the client socket in parent process
            // Clean up terminated child processes to avoid zombie processes
            while (waitpid(-1, NULL, WNOHANG) > 0)
                ;
        }
    }
    // Close the server socket
    close(server_socket);
    return 0;
}