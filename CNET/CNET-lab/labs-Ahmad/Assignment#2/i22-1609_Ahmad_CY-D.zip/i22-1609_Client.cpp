#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <cstring>
#include <iostream>
using namespace std;

#define SERVER_IP "127.0.0.1" // Change this to the IP address of the server

void PrintData(int sock)
{
    char buffer[256];
    string data;

    while (true)
    {
        int bytes_received = recv(sock, buffer, sizeof(buffer) - 1, 0);
        if (bytes_received <= 0)
        {
            perror("Receive failed or connection closed");
            break;
        }
        buffer[bytes_received] = '\0'; // Null-terminate the received data
        data = string(buffer);
        if (data == "Exit")
        {
            break;
        }
        cout << data << endl;
    }
}

int main()
{
    // Create the socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1)
    {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Setup the server address
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr(SERVER_IP);
    server_address.sin_port = htons(9001);

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_address, sizeof(server_address)) == -1)
    {
        perror("Connection to the server failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Send and receive data
    char choice;
    char rollnum[15], name[20];
    cout << "Are you a Student or Teacher or Exit? (S/T/E): ";
    cin >> choice;

    // Send the request to the server
    if (send(sock, &choice, sizeof(choice), 0) == -1)
    {
        perror("Send failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Check for exit condition
    if (choice == 'e' || choice == 'E')
    {
        cout << "Client has exited\n";
        close(sock);
        return 0;
    }
    else if (choice == 's' || choice == 'S')
    {
        cout << "Enter your Roll Number: ";
        cin >> rollnum;
        if (send(sock, rollnum, strlen(rollnum) + 1, 0) == -1) // Send null-terminated string
        {
            perror("Send failed");
        }
        PrintData(sock);
    }
    else if (choice == 't' || choice == 'T')
    {
        cout << "Enter your Name: ";
        cin >> name;
        if (send(sock, name, strlen(name) + 1, 0) == -1) // Send null-terminated string
        {
            perror("Send failed");
        }
        PrintData(sock);
    }
    else
    {
        cout << "Invalid choice. Exiting...\n";
    }

    // Close the socket
    close(sock);
    return 0;
}
