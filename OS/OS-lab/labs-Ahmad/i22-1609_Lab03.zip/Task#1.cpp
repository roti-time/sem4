#include <iostream>
#include <sys/wait.h>
#include <unistd.h>

using namespace std;
int count = 0;
int main()
{
    pid_t pid;
    for (int i = 0; i < 6; i++)
    {
        pid = fork();
    }
    if (pid == 0)
    {
        cout << "Hello World " << endl;
    }
    else if (pid < 0)
    {
        cout << "Error" << endl;
    }
    else
    {
        int status = 0;
        waitpid(pid, &status, 0);

        int res = WEXITSTATUS(status);
        cout << "Hello World" <<endl;
    }
    return 0;
}
