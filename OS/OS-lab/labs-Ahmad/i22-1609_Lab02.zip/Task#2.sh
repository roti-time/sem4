#!/bin/bash
count=9
echo $count
((count--))
echo $count
((count--))
echo $count
((count--))
echo $count
((count--))
echo $count
((count--))
echo $count
((count--))
echo $count
((count--))
echo $count
((count--))
echo $count
((count--))


