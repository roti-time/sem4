#!/bin/bash
rm /home/gnome/Desktop/script.sh
rm /home/gnome/Downloads/wow.txt
rm /home/gnome/Music/indeed.meh
