#!/bin/bash
date
myvar="Maryam Shahbaz"
marks=23
english=32
urdu=24
maths=13
echo "Name: " $myvar
echo "Total Marks: " $marks
echo "English: " $english
echo "Urdu: " $urdu
echo "Maths: " $maths
