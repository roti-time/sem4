# CandyCrush_AssemblyLanguage
A Candy Crush game board coded in Assembly (x86). Displays candies on a grid. Includes basic gameplay mechanics and candy variations. 
